import { createWorker } from 'tesseract.js';
import { UploadedDocument, ExtractedField } from '@/contexts/FormContext';

// Helper function to extract text from image using Tesseract OCR
async function extractTextFromImage(file: File): Promise<string> {
  let worker: any = null;
  
  try {
    console.log(`Creating new Tesseract worker for file: ${file.name} (${file.size} bytes)`);
    
    // Always create a fresh worker to avoid caching issues
    worker = await createWorker('eng', 1, {
      logger: (m) => {
        // Optional: log progress
        if (m.status === 'recognizing text') {
          console.log(`OCR Progress: ${Math.round(m.progress * 100)}%`);
        }
      },
    });

    console.log(`Recognizing text from file: ${file.name}`);
    const { data: { text } } = await worker.recognize(file);
    
    console.log(`Text extraction completed. Length: ${text.length}`);
    
    // Always terminate worker to free resources
    await worker.terminate();
    worker = null;
    
    return text;
  } catch (error) {
    console.error(`Error in extractTextFromImage for ${file.name}:`, error);
    // Make sure to terminate worker even on error
    if (worker) {
      try {
        await worker.terminate();
      } catch (terminateError) {
        console.error('Error terminating worker:', terminateError);
      }
    }
    throw error;
  }
}

// Helper function to extract text from PDF (convert first page to image)
async function extractTextFromPDF(file: File): Promise<string> {
  // For PDF, we'll need to convert it to an image first
  // This is a simplified version - in production, you'd use pdf.js or similar
  // For now, we'll return empty and handle PDFs differently
  return '';
}

// Parse extracted text to find specific fields
function parseExtractedText(text: string, documentType: UploadedDocument['type']): ExtractedField[] {
  const fields: ExtractedField[] = [];
  const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  
  // Common patterns for Indian documents
  const namePatterns = [
    /(?:name|नाम|NAME)[\s:]*([A-Z][a-zA-Z\s]{2,30})/i,
    /^([A-Z][a-zA-Z\s]{2,30})$/,
    /([A-Z][a-zA-Z]+(?:\s+[A-Z][a-zA-Z]+){1,3})/,
  ];

  const dobPatterns = [
    /(?:dob|date of birth|जन्म तिथि|DOB)[\s:]*(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/i,
    /(\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{2,4})/,
  ];

  const genderPatterns = [
    /(?:gender|लिंग|GENDER)[\s:]*((?:MALE|FEMALE|M|F|पुरुष|महिला)+)/i,
  ];

  const aadhaarPatterns = [
    /(\d{4}\s?\d{4}\s?\d{4})/,
    /(?:aadhaar|aadhar|आधार)[\s:]*(\d{4}\s?\d{4}\s?\d{4})/i,
  ];

  const panPatterns = [
    /([A-Z]{5}\d{4}[A-Z]{1})/,
    /(?:pan|पैन)[\s:]*([A-Z]{5}\d{4}[A-Z]{1})/i,
  ];

  const pincodePatterns = [
    /(\d{6})/,
    /(?:pincode|pin code|पिन कोड)[\s:]*(\d{6})/i,
  ];

  const addressPatterns = [
    /(?:address|पता|ADDRESS)[\s:]*([A-Za-z0-9\s,.-]{10,100})/i,
  ];

  // Extract full name
  let fullName = '';
  for (const pattern of namePatterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      const candidate = match[1].trim();
      // Filter out common false positives
      if (!candidate.match(/^(GOVERNMENT|INDIA|REPUBLIC|OF|THE|AADHAAR|PAN|CARD)$/i) && 
          candidate.length >= 3 && candidate.length <= 50) {
        fullName = candidate;
        break;
      }
    }
  }
  
  // If no pattern match, try to find the longest capitalized word sequence
  if (!fullName) {
    const capitalizedLines = lines.filter(line => 
      line.match(/^[A-Z][a-zA-Z\s]{2,30}$/) && 
      !line.match(/^(GOVERNMENT|INDIA|REPUBLIC|OF|THE|AADHAAR|PAN|CARD|NUMBER|DATE|BIRTH)$/i)
    );
    if (capitalizedLines.length > 0) {
      fullName = capitalizedLines[0];
    }
  }

  if (fullName) {
    fields.push({
      key: 'fullName',
      value: fullName,
      confidence: 'high',
      source: documentType === 'aadhaar' ? 'Aadhaar' : documentType === 'pan' ? 'PAN Card' : 'Document',
    });
  }

  // Extract date of birth
  for (const pattern of dobPatterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      fields.push({
        key: 'dateOfBirth',
        value: match[1],
        confidence: 'high',
        source: documentType === 'aadhaar' ? 'Aadhaar' : documentType === 'pan' ? 'PAN Card' : 'Document',
      });
      break;
    }
  }

  // Extract gender
  for (const pattern of genderPatterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      const gender = match[1].toUpperCase();
      const genderValue = gender.includes('MALE') || gender === 'M' || gender.includes('पुरुष') ? 'Male' : 
                         gender.includes('FEMALE') || gender === 'F' || gender.includes('महिला') ? 'Female' : '';
      if (genderValue) {
        fields.push({
          key: 'gender',
          value: genderValue,
          confidence: 'medium',
          source: documentType === 'aadhaar' ? 'Aadhaar' : 'Document',
        });
        break;
      }
    }
  }

  // Extract Aadhaar number
  for (const pattern of aadhaarPatterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      const aadhaar = match[1].replace(/\s/g, '');
      if (aadhaar.length === 12) {
        fields.push({
          key: 'aadhaarNumber',
          value: `${aadhaar.substring(0, 4)} ${aadhaar.substring(4, 8)} ${aadhaar.substring(8, 12)}`,
          confidence: 'high',
          source: 'Aadhaar',
        });
        break;
      }
    }
  }

  // Extract PAN number
  for (const pattern of panPatterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      fields.push({
        key: 'panNumber',
        value: match[1],
        confidence: 'high',
        source: 'PAN Card',
      });
      break;
    }
  }

  // Extract pincode
  for (const pattern of pincodePatterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      const pin = match[1];
      if (pin.length === 6) {
        fields.push({
          key: 'pincode',
          value: pin,
          confidence: 'medium',
          source: documentType === 'aadhaar' ? 'Aadhaar' : 'Document',
        });
        break;
      }
    }
  }

  // Extract address (simplified - looks for longer text blocks)
  for (const pattern of addressPatterns) {
    const match = text.match(pattern);
    if (match && match[1]) {
      fields.push({
        key: 'address',
        value: match[1].trim(),
        confidence: 'medium',
        source: documentType === 'aadhaar' ? 'Aadhaar' : 'Document',
      });
      break;
    }
  }

  // If no address found, try to find long text blocks that might be addresses
  if (!fields.find(f => f.key === 'address')) {
    const longLines = lines.filter(line => line.length > 20 && line.length < 100);
    if (longLines.length > 0) {
      // Try to combine multiple lines that look like an address
      const addressCandidates = longLines.slice(0, 3).join(', ');
      if (addressCandidates.length > 10) {
        fields.push({
          key: 'address',
          value: addressCandidates,
          confidence: 'low',
          source: 'Document',
        });
      }
    }
  }

  return fields;
}

// Main extraction function
export async function extractDocumentData(documents: UploadedDocument[]): Promise<ExtractedField[]> {
  const allFields: ExtractedField[] = [];
  const fieldMap = new Map<string, ExtractedField>();

  console.log(`Processing ${documents.length} document(s)...`);

  for (const doc of documents) {
    try {
      console.log(`Processing document: ${doc.file.name} (type: ${doc.file.type})`);
      let extractedText = '';

      if (doc.file.type === 'application/pdf') {
        // For PDFs, we'd need pdf.js to convert to image first
        // For now, skip PDF OCR (you can implement this later)
        console.warn('PDF OCR not fully implemented. Please use image files for better results.');
        continue;
      } else {
        // Extract text from image
        console.log(`Extracting text from image: ${doc.file.name}`);
        extractedText = await extractTextFromImage(doc.file);
        console.log(`Extracted text length: ${extractedText.length} characters`);
        console.log(`Extracted text preview: ${extractedText.substring(0, 200)}...`);
      }

      if (!extractedText || extractedText.trim().length === 0) {
        console.warn(`No text extracted from ${doc.file.name} - OCR may have failed or image has no text`);
        continue;
      }

      // Parse the extracted text
      console.log(`Parsing extracted text for ${doc.file.name}...`);
      const parsedFields = parseExtractedText(extractedText, doc.type);
      console.log(`Found ${parsedFields.length} fields:`, parsedFields.map(f => `${f.key}: ${f.value}`));

      // Merge fields, keeping the highest confidence value
      for (const field of parsedFields) {
        const existing = fieldMap.get(field.key);
        if (!existing || 
            (field.confidence === 'high' && existing.confidence !== 'high') ||
            (field.confidence === 'medium' && existing.confidence === 'low')) {
          fieldMap.set(field.key, field);
        }
      }
    } catch (error) {
      console.error(`Error processing ${doc.file.name}:`, error);
      // Continue processing other documents even if one fails
    }
  }

  // Convert map to array
  const result = Array.from(fieldMap.values());
  console.log(`Total extracted fields: ${result.length}`);

  // Ensure common fields exist (even if empty)
  const commonFields = ['fullName', 'dateOfBirth', 'gender', 'fatherName', 'address', 'pincode', 'state', 'aadhaarNumber', 'panNumber', 'mobileNumber'];
  for (const key of commonFields) {
    if (!result.find(f => f.key === key)) {
      result.push({
        key,
        value: '',
        confidence: 'low',
        source: 'Not found',
      });
    }
  }

  console.log(`Final result with all fields: ${result.length} fields`);
  return result;
}

